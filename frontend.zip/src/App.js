import logo from './logo.svg';
import './App.css';
import ChatGPTWithSearch from './components/ChatGPTWithSearch';

function App() {
  return (
<ChatGPTWithSearch />
  );
}

export default App;
