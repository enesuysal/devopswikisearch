// src/components/ChatGPTWithSearch.js
import React, { useState } from 'react';
import axios from 'axios';

const ChatGPTWithSearch = () => {
  const [userInput, setUserInput] = useState('');
  const [response, setResponse] = useState('');
  const [links, setLinks] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e) => {
    setUserInput(e.target.value);
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      const res = await axios.post('http://localhost:5000/ask', { question: userInput });
      setResponse(res.data.summary);
      setLinks(res.data.links); // Now links contain title + link
    } catch (error) {
      setResponse('Error occurred while processing your request.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>DevOps Wiki Helper</h2>
      <textarea
        value={userInput}
        onChange={handleInputChange}
        placeholder="Ask a question..."
        rows={4}
        style={{ width: '100%', padding: '10px' }}
      />
      <button onClick={handleSubmit} disabled={isLoading} style={{ marginTop: '10px', padding: '10px' }}>
        {isLoading ? 'Loading...' : 'Send'}
      </button>

      {response && (
        <div style={{ marginTop: '20px' }}>
          <h4>Summary:</h4>
          <p>{response}</p>
          <h4>Relevant Wiki Links:</h4>
          <ul>
            {links.map((result, index) => (
              <li key={index}>
                <a href={result.link} target="_blank" rel="noopener noreferrer">
                  {result.title}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ChatGPTWithSearch;
